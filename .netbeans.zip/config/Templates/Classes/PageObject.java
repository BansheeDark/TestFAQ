<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

<#if package?? && package != "">
package ${package};

</#if>

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import com.codeborne.selenide.SelenideElement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.Point;

/**
 * Каждая страница на сайте имеет свою PageObject в проекте.
 *
 * @author ${user}
 */
public class ${name}
{

    /*
    Вызов шаблона кода (шаблон + TAB).
    Виды шаблонов:
    csm - клик по объекту.
    ssm - напечатать текст в объект.
    gsm - возврат текста объекта.
    lsm - возврат List<SelenideElement>. 
    cntsm - возврат кол-во эл-в в list.
     */
    // <editor-fold desc="Field">
    /**
     * Параметр log. Обращаться из класса для записи лога.
     */
    private static Logger log;
// </editor-fold>

    /**
     * Конструктор страницы объектов. Указывает имя класса, записи которого
     * будут вносится в лог.
     */
    public ${name}()
    {
        ${name}.log.setUseParentHandlers(true);
        log = Logger.getLogger(${name}.class.getName());
    }

    /**
     * Конструктор страницы объектов. Указывает имя класса, записи которого
     * будут вносится в лог, при соответствующем значении параметра log.
     *
     * @param log false - отключает логирование.
     */
    public ${name}(boolean log)
    {
        ${name}.log.setUseParentHandlers(log);
        ${name}.log = Logger.getLogger(${name}.class.getName());
    }

    // <editor-fold desc="set">

// </editor-fold>
    // <editor-fold desc="click">

// </editor-fold>
    // <editor-fold desc="Get">

// </editor-fold>
    // <editor-fold desc="list">

// </editor-fold>
    // <editor-fold desc="count">

// </editor-fold>
}
